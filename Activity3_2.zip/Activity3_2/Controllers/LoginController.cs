﻿using Activity3_2.Models;
using Activity3_2.Services.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Activity3_2.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View("Login");
        }
        [HttpPost]
        public ActionResult Login(UserModel user)
        {
            if (!ModelState.IsValid)
            {
                return View("Login");
            }

            SecurityService securityService = new SecurityService();
            Boolean success = securityService.Authenticate(user);

            if (success)
            {
                return View("LoginSuccess", user);

            }
            else
            {
                return View("LoginFailed");
            }
        }
    }
}