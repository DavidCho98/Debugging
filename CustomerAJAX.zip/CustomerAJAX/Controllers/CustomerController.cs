﻿using CustomerAJAX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CustomerAJAX.Controllers
{
    public class CustomerController : Controller
    {

        Customer customer;

        List<Customer> customers;

        public CustomerController()
        {
            customers = new List<Customer>();

            customers.Add(new Customer(0, "Sherry", 37));
            customers.Add(new Customer(1, "David", 22));
            customers.Add(new Customer(2, "Jessica", 23));
            customers.Add(new Customer(3, "Hermes", 54));
            customers.Add(new Customer(4, "Cyrus", 12));
            customers.Add(new Customer(5, "Bora", 10));
            customers.Add(new Customer(6, "Safa", 7));
        }

        // GET: Customer
        public ActionResult Index()
        {

            Tuple<List<Customer>, Customer> tuple;
            tuple = new Tuple<List<Customer>, Customer>(customers, customers[2]);

            return View("Customer",tuple);
        }

        [HttpPost]
        public ActionResult OnSelectCustomer(string CustomerNumber)
        {

            Tuple<List<Customer>, Customer> tuple;
            tuple = new Tuple<List<Customer>, Customer>(customers, customers[Int32.Parse(CustomerNumber)]);

            return PartialView("_CustomerDetails", customers[Int32.Parse(CustomerNumber)]);
        }
    }
}