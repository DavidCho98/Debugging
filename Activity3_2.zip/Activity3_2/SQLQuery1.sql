﻿INSERT INTO dbo.users(USERNAME, PASSWORD) VALUES ('Zeo','test1');
